// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("dast scan\n", stdout);
  return lionss_run_workload("dast-scan");
}
