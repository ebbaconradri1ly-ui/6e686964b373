// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("memory sanitizer"); }
int main(){
  announce();
  return lionss_run_workload("memory-sanitizer");
}
