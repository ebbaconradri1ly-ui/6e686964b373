// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("headless tests"); }
int main(){
  announce();
  return lionss_run_workload("headless-tests");
}
