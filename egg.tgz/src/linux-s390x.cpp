// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("linux s390x"); }
int main(){
  announce();
  return lionss_run_workload("linux-s390x");
}
