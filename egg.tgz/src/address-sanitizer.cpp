// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("address sanitizer\n", stdout);
  return lionss_run_workload("address-sanitizer");
}
