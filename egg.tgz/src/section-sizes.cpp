// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("section sizes"); }
int main(){
  announce();
  return lionss_run_workload("section-sizes");
}
