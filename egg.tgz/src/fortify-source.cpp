// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("fortify source\n", stdout);
  return lionss_run_workload("fortify-source");
}
