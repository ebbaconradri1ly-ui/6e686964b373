// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("whitespace check\n", stdout);
  return lionss_run_workload("whitespace-check");
}
